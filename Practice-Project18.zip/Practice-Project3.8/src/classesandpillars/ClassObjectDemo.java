package classesandpillars;

//Example demonstrating classes and objects
class Car {
	String brand;
	String model;

	public Car(String brand, String model) {
		this.brand = brand;
		this.model = model;
	}

	public void displayDetails() {
		System.out.println("Brand: " + brand);
		System.out.println("Model: " + model);
	}
}

public class ClassObjectDemo {
	public static void main(String[] args) {
		// Creating objects of the Car class
		Car car1 = new Car("Tata", "Nano");
		Car car2 = new Car("Honda", "Civic");

		// Displaying details of cars using objects
		System.out.println("Car 1 Details:");
		car1.displayDetails();

		System.out.println("\nCar 2 Details:");
		car2.displayDetails();
	}
}
