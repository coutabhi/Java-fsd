package classesandpillars;

//Example demonstrating inheritance
class Vehicle {
	public void start() {
		System.out.println("Vehicle starting...");
	}
}

class Cars extends Vehicle {
	public void drive() {
		System.out.println("Car driving...");
	}
}

public class InheritanceDemo {
	public static void main(String[] args) {
		Cars car = new Cars();
		car.start();
		car.drive(); 
	}
}
