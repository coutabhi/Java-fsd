package classesandpillars;

//Example demonstrating encapsulation
class Employee {
	private int employeeId;
	private String employeeName;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
}

public class EncapsulationDemo {
	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.setEmployeeId(101);
		emp.setEmployeeName("Abhishek Yadav");

		System.out.println("Employee ID: " + emp.getEmployeeId());
		System.out.println("Employee Name: " + emp.getEmployeeName());
	}
}
