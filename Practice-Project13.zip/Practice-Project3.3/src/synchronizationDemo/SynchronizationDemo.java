package synchronizationDemo;

class SharedResource {
	public synchronized void doOperation(int threadId) {
		System.out.println("Thread " + threadId + " is accessing the shared resource.");
		
		//Perform some operations	
		try {
			Thread.sleep(2000); // Simulating some work
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Thread " + threadId + " finished accessing the shared resource.");
	}
}

public class SynchronizationDemo {

	public static void main(String[] args) {
		SharedResource sharedResource = new SharedResource(); //Shared Resource
		
		// Create multiple threads accessing the shared resource
		Thread thread1 = new Thread(() -> {
			sharedResource.doOperation(1);
		});
		
		Thread thread2 = new Thread(() -> {
			sharedResource.doOperation(2);
		});
		
		thread1.start();
		thread2.start();
	}

}
