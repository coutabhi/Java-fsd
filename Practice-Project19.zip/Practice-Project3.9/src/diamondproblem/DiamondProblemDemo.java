package diamondproblem;

interface Worker {
 void work();
}

interface Engineer extends Worker {
 default void work() {
     System.out.println("Engineer is engineering...");
 }
}

interface Artist extends Worker {
 default void work() {
     System.out.println("Artist is creating art...");
 }
}

class Robot implements Engineer, Artist {
 // Resolving the conflict by providing its own implementation
 @Override
 public void work() {
     Engineer.super.work();
     Artist.super.work();
     
     System.out.println("Robot is working...");
 }
}

public class DiamondProblemDemo {
 public static void main(String[] args) {
     Robot robot = new Robot();
     robot.work();
 }
}

