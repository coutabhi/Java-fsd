package arrayDemo;

public class ArrayDemo {

    public static void main(String[] args) {
        // Single-dimensional array
        int[] intArray = new int[5]; // An integer array of size 5

        // Assigning values to the integer array
        for (int i = 0; i < intArray.length; i++) {
            intArray[i] = i + 1;
        }

        // Accessing and printing array elements
        System.out.println("Elements of intArray:");
        for (int num : intArray) {
            System.out.print(num + " ");
        }
        System.out.println();
        
        System.out.println("Length of array: " + intArray.length);
        

        // Multidimensional array
        int[][] multiDimensionalArray = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };

        // Accessing and printing elements of the 2D array
        System.out.println("\nElements of multiDimensionalArray:");

        for (int i = 0; i < multiDimensionalArray.length; i++) {
            for (int j = 0; j < multiDimensionalArray[i].length; j++) {
                System.out.print(multiDimensionalArray[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("\nLength of row 1: " + multiDimensionalArray[0].length);
        System.out.println("\nLength of row 2: " + multiDimensionalArray[1].length);
    }
}

