package tryCatch;

public class TryCatchDemo {

	public static int divide(int dividend, int divisor) {
		if (divisor == 0) {
			throw new ArithmeticException("Divison by zero");
		}
		return dividend / divisor;
	}

	public static void main(String[] args) {
		try {
			int[] numbers = { 1, 2, 3 };
			System.out.println("Accessing element at index 3: " + numbers[3]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Exception caught: Array index out of bounds");
		} finally {
			System.out.println("This block always executes regardless of exception occurence");
		}

		try {
			int result = divide(10, 0);
			System.out.println("Result of division: " + result);
		} catch (ArithmeticException e) {
			System.out.println("Exception caught: Division by zero");
		}
	}

}
