package threadsCreation;

public class ThreadDemo extends Thread {

	public void run() {
		System.out.println("This is the ThreadDemo thread.");
	}

	public static void main(String[] args) {
		ThreadDemo td = new ThreadDemo();
		td.start(); // start is the abstract class of the thread.
		System.out.println("This is the main thread");
	}
	
}
