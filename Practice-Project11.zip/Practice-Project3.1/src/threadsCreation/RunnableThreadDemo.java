package threadsCreation;

public class RunnableThreadDemo implements Runnable  {
	public static int count = 0;
	
	
	
	public void run() {
		while(count <= 10 ) {
			try {
				System.out.println("Runnable thread: " + count);
				Thread.sleep(1000);
			}catch(InterruptedException exc) {
				System.out.println("There is error: " + exc.getMessage());
			}
		}
	}

	public static void main(String[] args) {
		System.out.println("This is the main thread");
		RunnableThreadDemo rtd = new RunnableThreadDemo();
		Thread td = new Thread(rtd);
		td.start();
		while(count <= 10 ) {
			try {
				System.out.println("Main thread: " + count);
				Thread.sleep(1000);
				count++;
			}catch(InterruptedException exc) {
				System.out.println("There is error: " + exc.getMessage());
			}
		}
	}
	
}
