package orderstatistics;

public class OrderStatistics {
	public int findKthSmallest(int[] arr, int k) {
		if (arr == null || arr.length < k) {
			System.out.println("Invalid input");
			return -1;
		}
		return quickSelect(arr, 0, arr.length - 1, k - 1);
	}

	private int quickSelect(int[] arr, int left, int right, int k) {
		if (left <= right) {
			int partitionIndex = partition(arr, left, right);

			if (partitionIndex == k) {
				return arr[partitionIndex];
			} else if (partitionIndex < k) {
				return quickSelect(arr, partitionIndex + 1, right, k);
			} else {
				return quickSelect(arr, left, partitionIndex - 1, k);
			}
		}
		return -1;
	}

	private int partition(int[] arr, int left, int right) {
		int pivot = arr[right];
		int i = left - 1;

		for (int j = left; j < right; j++) {
			if (arr[j] < pivot) {
				i++;
				swap(arr, i, j);
			}
		}

		swap(arr, i + 1, right);
		return i + 1;
	}

	private void swap(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
}
