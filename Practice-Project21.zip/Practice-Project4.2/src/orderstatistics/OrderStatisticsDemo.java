package orderstatistics;

public class OrderStatisticsDemo {
	public static void main(String[] args) {
		int[] arr = { 10, 5, 8, 2, 7, 3, 9, 1, 6, 4 };

		int k = 4;
		OrderStatistics od = new OrderStatistics();
		int thatElement = od.findKthSmallest(arr, k);
		System.out.println("The " + k + "th smallest element in the array is: " + thatElement);
	}

	
}
