
// Practice Project 1- Type Casting
/* Implicit Type casting occurs when lower data type converted to a higher data type (example: int to double, float to double)
 * Explicit Type casting occurs when higher data type converted to a lower data type (example: double to int, double to float) 
 * */
package typeCasting;

public class TypeCasting {
	
	public static void  main(String[] args) {	
		int myInt = 10;
		double myDouble = myInt; // Implicitly converting int to double
		System.out.println("-----Implicit Type Casting-----");
		System.out.println("Integer value: " + myInt);
		System.out.println("Double value after implicit casting: " + myDouble);
		
		// Explicit type casting (Narrowing Conversion)
		double anotherDouble = 7.75;
		int anotherInt = (int) anotherDouble; // Explicitly converting double to int
		System.out.println("\n-----Explicit Type Casting-----");
		System.out.println("Double value: " + anotherDouble);
		System.out.println("Integer value after explicit casting: " + anotherInt);
	}
	
}
