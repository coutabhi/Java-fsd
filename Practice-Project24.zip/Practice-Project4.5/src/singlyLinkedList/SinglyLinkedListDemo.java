package singlyLinkedList;

import java.util.LinkedList;

public class SinglyLinkedListDemo {

	public static void main(String[] args) {
		LinkedList<Integer> list = new LinkedList<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(3);
		list.add(4);
		list.add(5);

		System.out.println("Original List:" + list);
		int keyToDelete = 3;
		boolean removed = list.removeFirstOccurrence(keyToDelete);

		if (removed) {
			System.out.println("First occurrence of " + keyToDelete + " deleted.");
		} else {
			System.out.println(keyToDelete + " not found in the LinkedList.");
		}

		System.out.println("Updated LinkedList: " + list);
	}
}
