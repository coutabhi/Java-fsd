package innerClasses;

public class OuterClasses {
	private int outerVariable = 10;

    // Inner class
    class InnerClass {
        void display() {
            System.out.println("Value of outerVariable from InnerClass: " + outerVariable);
        }
    }

	public static void main(String[] args) {
		OuterClasses outer = new OuterClasses();
		OuterClasses.InnerClass inner = outer.new InnerClass();
        inner.display();
	}
}
