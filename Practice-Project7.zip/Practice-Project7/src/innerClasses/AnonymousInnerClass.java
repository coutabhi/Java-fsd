package innerClasses;

interface Greeting {
    void greet();
}

public class AnonymousInnerClass {

	public static void main(String[] args) {
		// Creating an instance of the interface using an anonymous inner class
        Greeting greeting = new Greeting() {
            @Override
            public void greet() {
                System.out.println("This is an anonymous inner class implementation!");
            }
        };

        greeting.greet();
	}

}
