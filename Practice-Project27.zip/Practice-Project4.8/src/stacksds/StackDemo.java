package stacksds;

public class StackDemo {
	private int maxSize;
	private int[] stackArray;
	private int top;

	public StackDemo(int size) {
		this.maxSize = size;
		this.stackArray = new int[maxSize];
		this.top = -1;
	}

	public void push(int value) {
		if (isFull()) {
			System.out.println("Stack is full. Cannot push " + value);
		} else {
			top++;
			stackArray[top] = value;
			System.out.println("Pushed " + value + " into the stack");
		}
	}

	public int pop() {
		if (isEmpty()) {
			System.out.println("Stack is empty. Cannot pop an element.");
			return -1; // Return some default value indicating failure
		} else {
			int poppedValue = stackArray[top];
			top--;
			System.out.println("Popped " + poppedValue + " from the stack");
			return poppedValue;
		}
	}

	public int peek() {
		if (isEmpty()) {
			System.out.println("Stack is empty. No element to peek.");
			return -1;
		} else {
			return stackArray[top];
		}
	}

	public boolean isEmpty() {
		return (top == -1);
	}

	public boolean isFull() {
		return (top == maxSize - 1);
	}

	public static void main(String[] args) {
		int stackSize = 5;
		StackDemo stack = new StackDemo(stackSize);

		stack.push(10);
		stack.push(20);
		stack.push(30);
		stack.push(40);
		stack.push(50);

		stack.push(60);

		stack.pop();
		stack.pop();
		stack.pop();
		stack.pop();
		stack.pop();
		stack.pop();

		stack.push(70);
	}
}
