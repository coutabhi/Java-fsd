package arrayRotation;

public class ArrayRotationDemo {
	
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
    
    public static void main(String[] args) {
        int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        System.out.println("Original Array:");
        printArray(arr);

        int rotationSteps = 9;
        rotateArray(arr, rotationSteps);

        System.out.println("\nArray after rotating by 5 steps to the right:");
        printArray(arr);
    }

    public static void rotateArray(int[] arr, int k) {
        int len = arr.length;
        k %= len;

        reverseArray(arr, 0, len - 1);
        reverseArray(arr, 0, k - 1);
        reverseArray(arr, k, len - 1);
    }


    public static void reverseArray(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
//        printArray(arr);
    }

    
}
