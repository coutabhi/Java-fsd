package doublylinkedlist;

public class DoublyLinkedList {
	static class Node {
		int data;
		Node prev;
		Node next;

		Node(int d) {
			data = d;
			prev = null;
			next = null;
		}
	}

	Node head;

	DoublyLinkedList() {
		head = null;
	}

	void insertAtEnd(int data) {
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
		} else {
			Node temp = head;
			while (temp.next != null) {
				temp = temp.next;
			}
			temp.next = newNode;
			newNode.prev = temp;
		}
	}

	void traverseForward() {
		if (head == null) {
			System.out.println("Doubly Linked List is empty.");
			return;
		}

		System.out.print("Forward traversal: ");
		Node temp = head;
		while (temp != null) {
			System.out.print(temp.data + " ");
			temp = temp.next;
		}
		System.out.println();
	}

	void traverseBackward() {
		if (head == null) {
			System.out.println("Doubly Linked List is empty.");
			return;
		}

		System.out.print("Backward traversal: ");
		Node temp = head;
		while (temp.next != null) {
			temp = temp.next;
		}

		while (temp != null) {
			System.out.print(temp.data + " ");
			temp = temp.prev;
		}
		System.out.println();
	}

	public static void main(String[] args) {
		DoublyLinkedList list = new DoublyLinkedList();
		list.insertAtEnd(5);
		list.insertAtEnd(10);
		list.insertAtEnd(15);

		list.traverseForward();
		list.traverseBackward();
	}
}
