package regularExpression;

import java.util.regex.*;

public class RegularExpressionDemo {
	public static void main(String[] args) {
	  String[] stringsToSearch = {
	            "apple",
	            "banana",
	            "orange",
	            "pineapple",
	            "grapefruit"
	        };

	        String patternToSearch = "apple";

	        Pattern pattern = Pattern.compile(patternToSearch);
	        System.out.println();
	        // Search for the pattern in each string
	        for (String str : stringsToSearch) {
	            Matcher matcher = pattern.matcher(str);

	            if (matcher.find()) {
	                System.out.println("Pattern found in string: " + str);
	            } else {
	                System.out.println("Pattern not found in string: " + str);
	            }
	        }
	}	
}
