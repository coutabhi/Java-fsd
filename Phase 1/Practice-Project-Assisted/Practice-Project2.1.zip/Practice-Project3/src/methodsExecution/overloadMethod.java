package methodsExecution;

public class overloadMethod {
	
	public void add(int x, int y) {
		System.out.println("Addition of two numbers is: " + (x + y));
	}
	public void add(int x, int y, int z) {
		System.out.println("Addition of three numbers is: " + (x + y + z));
	}
	public void add(double x, double y, double z) {
		System.out.println("Addition of three numbers is: " + (x + y + z));
	}

	public static void main(String[] args) {
		overloadMethod ov = new overloadMethod();
		
		ov.add(10, 20);
		ov.add(10, 20, 30);
		ov.add(10.5, 20.7, 30.5);
	}
}
