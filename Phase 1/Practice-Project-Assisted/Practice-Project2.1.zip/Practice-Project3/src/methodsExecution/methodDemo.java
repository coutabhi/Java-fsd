package methodsExecution;

public class methodDemo {
	public int addNumbers(int a, int b) {
		int z = a + b;
		return z;
	}
	public static void main(String[] args) {
		methodDemo b = new methodDemo();
		int ans = b.addNumbers(10, 3);
		System.out.println("Addition is + " + ans);
	}
}
