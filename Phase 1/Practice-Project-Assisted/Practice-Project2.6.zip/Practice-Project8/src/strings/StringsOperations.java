package strings;

public class StringsOperations {
	public static void stringMethods() {
	    // Methods of Strings
	    System.out.println("Strings Methods");

	    String sl = new String("Hello Java");
	    System.out.println("Length of sl: " + sl.length());

	    // Substring
	    String sub = new String("Program");
	    System.out.println("Substring of sub: " + sub.substring(2));

	    // String Comparison
	    String s1 = "Hello";
	    String s2 = "Heldo";
	    System.out.println("Comparison of s1 and s2: " + s1.compareTo(s2));

	    // IsEmpty
	    String s4 = "";
	    System.out.println("Is s4 empty?: " + s4.isEmpty());

	    // toLowerCase
	    String s5 = "Hello";
	    System.out.println("s1 in lowercase: " + s5.toLowerCase());

	    // Replace
	    String s6 = "Heldo";
	    String replace = s6.replace('d', 'l');
	    System.out.println("Replacement in s6: " + replace);

	    // Equals
	    String x = "Welcome to Java";
	    String y = "WeLcOmE tO JaVa";
	    System.out.println("Equality check of x and y: " + x.equals(y));
	    System.out.println();
	}

	public static void stringBufferMethods() {
	    // Creating StringBuffer
	    System.out.println("Creating StringBuffer");

	    // Creating StringBuffer and append method
	    StringBuffer s = new StringBuffer("Hello! World java");
	    s.append(" join the community");
	    System.out.println(s);

	    // Insert method
	    s.insert(0, 'w');
	    System.out.println(s);

	    // Replace method
	    StringBuffer sb = new StringBuffer("Hello");
	    sb.replace(0, 2, "hEl");
	    System.out.println(sb);

	    // Delete method
	    sb.delete(0, 1);
	    System.out.println(sb);
	    System.out.println();
	}

	public static void stringBuilderMethods() {
	    // Creating StringBuilder
	    System.out.println("Creating StringBuilder");

	    StringBuilder sb1 = new StringBuilder("Hello");
	    sb1.append(" Join");
	    System.out.println(sb1);

	    System.out.println(sb1.delete(0, 1));
	    System.out.println(sb1.insert(1, "Join"));
	    System.out.println(sb1.reverse());
	    System.out.println();
	}

	public static void convertString() {
	    // Conversion of Strings to StringBuffer and StringBuilder
	    System.out.println("Conversion of Strings to StringBuffer and StringBuilder");

	    String str = "Hello";

	    // Conversion from String object to StringBuffer
	    StringBuffer sbr = new StringBuffer(str);
	    sbr.reverse();
	    System.out.println("String to StringBuffer: " + sbr);

	    // Conversion from String object to StringBuilder
	    StringBuilder sbl = new StringBuilder(str);
	    sbl.append(" world");
	    System.out.println("String to StringBuilder: " + sbl);
	}
	public static void main(String[] args) {
		stringMethods();
        stringBufferMethods();
        stringBuilderMethods();
        convertString();
	}
}