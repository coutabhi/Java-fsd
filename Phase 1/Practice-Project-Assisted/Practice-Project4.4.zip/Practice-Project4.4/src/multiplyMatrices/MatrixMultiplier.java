package multiplyMatrices;

public class MatrixMultiplier {

	public void printMatrix(int[][] matrix) {
		for (int[] row : matrix) {
			for (int num : row) {
				System.out.print(num + " ");
			}
			System.out.println();
		}
	}

	public int[][] multiplyMatrices(int[][] mat1, int[][] mat2) {
		int rowsA = mat1.length;
		int colsA = mat1[0].length;
		int colsB = mat2[0].length;

		int[][] result = new int[rowsA][colsB];

		for (int i = 0; i < rowsA; i++) {
			for (int j = 0; j < colsB; j++) {
				for (int k = 0; k < colsA; k++) {
					result[i][j] += mat1[i][k] * mat2[k][j];
				}
			}
		}

		return result;
	}

}
