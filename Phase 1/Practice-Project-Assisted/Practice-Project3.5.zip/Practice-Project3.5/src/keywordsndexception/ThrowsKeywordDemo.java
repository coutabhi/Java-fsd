package keywordsndexception;

public class ThrowsKeywordDemo {
	
	public static void throwsMethod() throws Exception {
		throw new Exception("This is a custom exception using throws keyword.");
	}

	public static void main(String[] args) {
		try {
			throwsMethod();
		} catch(Exception e) {
			System.out.println("Exception caught: " + e.getMessage());
		}
	}

}
