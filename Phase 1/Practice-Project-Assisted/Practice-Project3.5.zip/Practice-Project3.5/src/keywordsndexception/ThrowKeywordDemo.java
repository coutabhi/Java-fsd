package keywordsndexception;

public class ThrowKeywordDemo {
	
	public static void throwMethod() throws Exception {
		throw new Exception("This is a custom exception using throw keyword.");
	}
	
	public static void main(String[] args) {
		try {
			throwMethod();
		} catch (Exception e) {
			System.out.println("Exception caught: " + e.getMessage());
		}
	}
	
}
