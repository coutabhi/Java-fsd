package keywordsndexception;

public class FinallyKeywordDemo {

	public static void main(String[] args) {
		try {
			System.out.println("Try block but this will give error");
			int result = 10 / 0;
			System.out.println("The result is: " + result);
		}catch(ArithmeticException e) {
			System.out.println("catch block that give error details");
			System.out.println("Error is " + e.getMessage());
		} finally {
			System.out.println("Finally block");
		}
	}

}
