package keywordsndexception;

@SuppressWarnings("serial")
class InvalidAgeException extends Exception {
	public InvalidAgeException(String message) {
		super(message);
	}
}

public class CustomExceptionDemo {
	
	public static void validateAge(int age) throws InvalidAgeException {
		if(age < 18) {
			throw new InvalidAgeException("Age should be 18 or above.");
		} else {
			System.out.println("Valid age");
		}
	}

	public static void main(String[] args) {
		try {
			validateAge(15);
		} catch (InvalidAgeException e) {
			System.out.println("Exception caught: " + e.getMessage());
		}
	}

}
