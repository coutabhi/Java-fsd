package binarysearch;

public class BinarySearchExample {
	
	public static boolean binarySearch(int[] arr, int target) {
		int start = 0;
		int end = arr.length;
		
		while(start <= end) {
			int mid = start + (end - start)/2;
			
			if(arr[mid] == target) {
				return true;
			}
			
			// if target is greater then  ignore the left half
			if(arr[mid] < target) {
				start = mid + 1;
			} else {
				end = mid - 1;
			}
		}
		return false;
	}

	public static void main(String[] args) {
		
		//As we know that binary search works only on the sorted array
		int[] sortedArray = { 12, 34, 45, 56, 67, 78, 89 };
		
		int elementToFind = 67;
		
		boolean isElementFound = binarySearch(sortedArray, elementToFind);
		
		if(isElementFound) {
			System.out.println("Element " + elementToFind + " found in the array.");
		} else {
			System.out.println("Element " + elementToFind + " not found in the array.");
		}
	}

}
