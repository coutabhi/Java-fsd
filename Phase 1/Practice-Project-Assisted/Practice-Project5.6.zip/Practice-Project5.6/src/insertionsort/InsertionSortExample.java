package insertionsort;

public class InsertionSortExample {

	public static void insertionSort(int[] arr) {
		int n = arr.length;

		for (int i = 1; i < n; ++i) {
			int unSortedFirstElement = arr[i];
			int j = i - 1;
			while (j >= 0 && arr[j] > unSortedFirstElement) {
				arr[j + 1] = arr[j];
				j = j - 1;
			}
			arr[j + 1] = unSortedFirstElement;
		}
	}

	public static void printArray(int[] arr) {
		for (int value : arr) {
			System.out.print(value + " ");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		int[] arr = { 15, 34, 16, 12, 67, 4, 90 };

		insertionSort(arr);

		System.out.println("Sorted array:");
		printArray(arr);
	}
}
