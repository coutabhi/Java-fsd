package circularll;

public class CircularLinkedListDemo {
	static class Node {
		int data;
		Node next;

		Node(int d) {
			data = d;
			next = null;
		}
	}

	Node head;

	CircularLinkedListDemo() {
		head = null;
	}

	void sortedInsert(int newData) {
		Node newNode = new Node(newData);

		if (head == null) {
			newNode.next = newNode;
			head = newNode;
		} else if (newNode.data <= head.data) {
			Node last = getLastNode();
			newNode.next = head;
			last.next = newNode;
			head = newNode;
		} else {
			Node current = head;
			while (current.next != head && current.next.data < newNode.data) {
				current = current.next;
			}
			newNode.next = current.next;
			current.next = newNode;
		}
	}

	Node getLastNode() {
		Node temp = head;
		while (temp.next != head) {
			temp = temp.next;
		}
		return temp;
	}

	void displayList() {
		if (head == null) {
			System.out.println("List is empty.");
			return;
		}

		Node temp = head;
		System.out.print("Circular Linked List: ");
		do {
			System.out.print(temp.data + " ");
			temp = temp.next;
		} while (temp != head);
		System.out.println();
	}

	public static void main(String[] args) {
		CircularLinkedListDemo list = new CircularLinkedListDemo();
		int[] arr = new int[] { 7, 18, 3, 12, 5 };
		for (int i = 0; i < 5; i++) {
			list.sortedInsert(arr[i]);
		}
		list.displayList();
	}
}
