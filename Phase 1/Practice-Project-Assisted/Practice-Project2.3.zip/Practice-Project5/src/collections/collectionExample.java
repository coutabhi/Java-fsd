package collections;

import java.util.ArrayList;
import java.util.Vector;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.LinkedList;

public class collectionExample {

    public static void main(String[] args) {
        // Creating an ArrayList
        ArrayList<String> arrayList = new ArrayList<>();

        // Adding elements to the ArrayList
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Orange");

        // Displaying elements of ArrayList
        System.out.println("ArrayList elements:");
        for (String fruit : arrayList) {
            System.out.println(fruit);
        }
        
        // Creating a Vector
        Vector<Integer> vector = new Vector<>();

        // Adding elements to the Vector
        vector.add(10);
        vector.add(20);
        vector.add(30);

        // Displaying elements of Vector
        System.out.println("\nVector elements:");
        for (int num : vector) {
            System.out.println(num);
        }
        
        // Creating a LinkedList
        LinkedList<String> linkedList = new LinkedList<>();

        // Adding elements to the LinkedList
        linkedList.add("Monday");
        linkedList.add("Tuesday");
        linkedList.add("Wednesday");

        // Displaying elements of LinkedList
        System.out.println("\nLinkedList elements:");
        for (String day : linkedList) {
            System.out.println(day);
        }
        
        // Creating a HashSet
        HashSet<String> hashSet = new HashSet<>();

        // Adding elements to the HashSet
        hashSet.add("Apple");
        hashSet.add("Banana");
        hashSet.add("Orange");
        hashSet.add("Banana"); // Adding a duplicate element (ignored in HashSet)

        // Displaying elements of HashSet
        System.out.println("\nHashSet elements:");
        for (String fruit : hashSet) {
            System.out.println(fruit);
        }
        
        // Creating a HashMap
        HashMap<Integer, String> hashMap = new HashMap<>();

        // Adding key-value pairs to the HashMap
        hashMap.put(1, "One");
        hashMap.put(2, "Two");
        hashMap.put(3, "Three");

        // Displaying elements of HashMap
        System.out.println("\nHashMap elements:");
        for (Map.Entry<Integer, String> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
    }
}

