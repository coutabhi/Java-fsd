package exceptionHandling;

public class ExceptionHandlingDemo {
	
	public static int divide(int dividend, int divisor) {
		return dividend / divisor;
	}

	public static void main(String[] args) {
		try {
			int result = divide(10, 0);
			System.out.println("Result of division: " + result);
		} catch(ArithmeticException e) {
			System.out.println("Exception caught: Division by zero");
		} finally {
			System.out.println("Finally block executed after ArithmeticException");
		}
		
		try {
			String str = null;
			@SuppressWarnings("null")
			int length = str.length();
			System.out.println("Length of string: " + length);
		} catch (NullPointerException e) {
			System.out.println("Null pointer exception");
		} finally {
			System.out.println("Finally block executed after NullPointerException");
		}
	}

}
