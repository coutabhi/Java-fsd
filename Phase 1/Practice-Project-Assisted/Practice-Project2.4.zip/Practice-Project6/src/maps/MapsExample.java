// Example of maps
package maps;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.Hashtable;

public class MapsExample {

    public static void main(String[] args) {
        // ------------------- HashMap ----------------------------
        Map<Integer, String> hashMap = new HashMap<>();

        hashMap.put(1, "One");
        hashMap.put(2, "Two");
        hashMap.put(3, "Three");

        System.out.println("HashMap elements:");
        for (Map.Entry<Integer, String> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }

        // ------------------- TreeMap ---------------------------------
        Map<Integer, String> treeMap = new TreeMap<>();

        treeMap.put(3, "Three");
        treeMap.put(1, "One");
        treeMap.put(2, "Two");

        System.out.println("\nTreeMap elements:");
        for (Map.Entry<Integer, String> entry : treeMap.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
        
        // --------------------- Hashtable ----------------------------------
        Map<Integer, String> hashtable = new Hashtable<>();

        hashtable.put(1, "One");
        hashtable.put(2, "Two");
        hashtable.put(3, "Three");

        System.out.println("\nHashtable elements:");
        for (Map.Entry<Integer, String> entry : hashtable.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
    }
}

