package accessmodifiers;

public class AccessModifier {
	
	// public access modifier
	public int publicVariable = 10;
	
	public void publicMethod() {
		System.out.println("Inside publicMethod\npublic access modifiers can be accessed from anywhere\n");
	}
	
	// protected access modifier
	protected int protectedVariable = 20;
	
	protected void protectedMethod() {
		System.out.println("Inside protected method\nprotected access modifiers can be accessed from within the same package or subclasses in different packages\n");
	}
	
	// private access modifier
	private int privateVariable = 30;
	
	private void privateMethod() {
		System.out.println("Inside private method\nprivate access modifiers can be accessed from only within the same class\n");
	}
	
	public void getPrivateVariable() {
		System.out.println("Private variable: " + privateVariable);
		privateMethod();
	}
	
	// default access modifier
	int defaultVariable = 40;
	
	void defaultMethod() {
		System.out.println("Inside default method\ndefault modifiers can be accessed within the same package\n");
	}
}
