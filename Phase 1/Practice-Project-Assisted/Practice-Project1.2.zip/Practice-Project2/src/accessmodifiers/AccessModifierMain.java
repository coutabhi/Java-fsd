package accessmodifiers;

public class AccessModifierMain {

	public static void main(String[] args) {
		AccessModifier accessModifier = new AccessModifier();
		
		
		// Accessing the public variable
		System.out.println("Public variable: " + accessModifier.publicVariable);	
		
		// Accessing the public method
		accessModifier.publicMethod();
		
		
		
		// Accessing the protected variable
		System.out.println("Protected variable: " + accessModifier.protectedVariable);
		
		// Accessing the protected method
		accessModifier.protectedMethod();
		
		
		
		// Accessing the private variable or method not possible from outside the class so un-commenting below two line gives error
		// System.out.println("Private variable: " + accessModifier.privateVariable);
		// accessmodifier.privateMethod();
		
		// We can access them by getters
		accessModifier.getPrivateVariable();
		
		
		
		// Accessing the default variable
		System.out.println("Default variable: " + accessModifier.defaultVariable);
		
		
		// Accessing the default method
		accessModifier.defaultMethod();
		
	}

}
