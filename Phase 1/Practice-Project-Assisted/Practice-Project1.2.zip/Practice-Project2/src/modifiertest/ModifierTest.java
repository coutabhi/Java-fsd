package modifiertest;
import accessmodifiers.*;

public class ModifierTest {
	public static void main(String[] args) {
		AccessModifier myNewObject = new AccessModifier();
		
		System.out.println("As we know we can access public variable or method from anywhere\nso the "
				+ "public variable is: " + myNewObject.publicVariable + "\nand public method is ");
		myNewObject.publicMethod();
		
		System.out.println("-----------------" );
		myNewObject.getPrivateVariable();  // we can access private data members or methods by only public getters or setters
	}
}
