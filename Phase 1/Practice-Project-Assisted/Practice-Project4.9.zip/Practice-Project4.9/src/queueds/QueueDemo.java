package queueds;

import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {
	public static void main(String[] args) {
		Queue<Integer> queue = new LinkedList<>();

		
		queue.offer(5);
		queue.offer(10);
		queue.offer(15);

		System.out.println("Queue elements: " + queue);

		int removedElement1 = queue.poll();
		System.out.println("Dequeued element: " + removedElement1);
		System.out.println("Queue elements after dequeue: " + queue);

		int removedElement2 = queue.poll();
		System.out.println("Dequeued element: " + removedElement2);
		System.out.println("Queue elements after dequeue: " + queue);
	}
}
