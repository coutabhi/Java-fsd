package linearsearch;

public class LinearSearchExample {

	public static boolean linearSearch(int[] arr, int target) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == target) {
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args) {
		int[] myArray = { 12, 45, 67, 89, 34, 56, 78 };

		int elementToFind = 67;

		boolean isElementFound = linearSearch(myArray, elementToFind);

		if (isElementFound) {
			System.out.println("Element " + elementToFind + " found in the array.");
		} else {
			System.out.println("Element " + elementToFind + " not found in the array.");
		}
	}

}
