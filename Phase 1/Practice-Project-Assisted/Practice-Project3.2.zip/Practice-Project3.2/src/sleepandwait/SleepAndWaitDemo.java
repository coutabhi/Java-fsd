package sleepandwait;

public class SleepAndWaitDemo {

	public static void main(String[] args) {
		final Object lock = new Object();
		//Object used for synchronization
		
		// Thread demonstrating sleep()
		Thread sleepThread = new Thread(() -> {
			try {
				System.out.println("Sleeping for 3 seconds...");
				Thread.sleep(3000); // sleep for 3 seconds
				System.out.println("Waking up after sleep.");
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
		});
		
		// Thread demonstrating wait()
		Thread waitThread = new Thread(() -> {
			synchronized (lock) {
				try {
					System.out.println("Waiting for notification...");
					lock.wait();
					System.out.println("Received notification and continuing execution.");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
		
		sleepThread.start();
		waitThread.start();
		
		// Notify the waiting thread after 5 seconds
		try {
			Thread.sleep(5000);  // Sleep for 5 seconds
			synchronized (lock) {
				lock.notify(); // Notify the waiting thread
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} 
	}

}
