package fileHandlingMech;

import java.io.*;
import java.nio.file.*;

public class FileUpdateDemo {

	public static void main(String[] args) {
		try {
			updateFileUsingFileWriter();
	        updateFileUsingNIO();
		} catch (Exception e) {
			System.out.println("An error occured.");
			e.printStackTrace();
		}
	}

	public static void updateFileUsingFileWriter() {
		try {
			FileWriter writer = new FileWriter("file_to_read.txt", true);
			writer.write("\nThis is new content added using FileWriter.");
			writer.close();
			System.out.println("File updated using FileWriter.");
		} catch (IOException e) {
			System.out.println("An error occurred while updating the file using FileWriter.");
			e.printStackTrace();
		}
	}

	public static void updateFileUsingNIO() {
		try {
			Path path = Paths.get("file_to_read.txt");
			String content = "\nThis is new content added using NIO.";
			Files.write(path, content.getBytes(), StandardOpenOption.APPEND);
			System.out.println("File updated using NIO.");
		} catch (IOException e) {
			System.out.println("An error occurred while updating the file using NIO.");
			e.printStackTrace();
		}
	}

}
