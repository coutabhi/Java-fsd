package fileHandlingMech;

import java.io.*;

public class FileReadingDemo {
	public static void main(String[] args) {
		try {
			readFileUsingFileInputStream();
			readFileUsingBufferedReader();
		} catch (Exception e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	public static void readFileUsingFileInputStream() {
		try {
			FileInputStream fis = new FileInputStream("file_to_read.txt");
			int data;
			while ((data = fis.read()) != -1) {
				System.out.print((char) data);
			}
			fis.close();
			System.out.println("\nFile read using FileInputStream.");
		} catch (IOException e) {
			System.out.println("An error occurred while reading the file using FileInputStream.");
			e.printStackTrace();
		}
	}

	public static void readFileUsingBufferedReader() {
		try {
			BufferedReader br = new BufferedReader(new FileReader("file_to_read.txt"));
			String line;
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
			br.close();
			System.out.println("File read using BufferedReader.");
		} catch (IOException e) {
			System.out.println("An error occurred while reading the file using BufferedReader.");
			e.printStackTrace();
		}
	}
}
