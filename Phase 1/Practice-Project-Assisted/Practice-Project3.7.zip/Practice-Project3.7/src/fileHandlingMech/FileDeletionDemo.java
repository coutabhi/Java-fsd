package fileHandlingMech;

import java.io.*;
import java.nio.file.*;

public class FileDeletionDemo {

	public static void main(String[] args) {
		try {
			deleteFileUsingFileClass();
			deleteFileUsingNIO();
		} catch (Exception e) {
			System.out.print("An error occurs mostly here FileNotFoundException comes");
			e.printStackTrace();
		}
	}

	// Method to delete a file using File class
	public static void deleteFileUsingFileClass() {
		try {
			File file = new File("file_to_delete1.txt");
			if (file.delete()) {
				System.out.println("File deleted using File class.");
			} else {
				System.out.println("Failed to delete the file.");
			}
		} catch (Exception e) {
			System.out.println("An error occurred while deleting the file using File class.");
			e.printStackTrace();
		}
	}

	// Method to delete a file using Files.delete (NIO)
	public static void deleteFileUsingNIO() {
		try {
			Path path = Paths.get("file_to_delete.txt");
			Files.delete(path);
			System.out.println("File deleted using NIO.");
		} catch (IOException e) {
			System.out.println("An error occurred while deleting the file using NIO.");
			e.printStackTrace();
		}
	}

}
