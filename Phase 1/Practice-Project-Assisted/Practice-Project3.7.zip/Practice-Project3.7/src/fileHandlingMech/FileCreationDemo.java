package fileHandlingMech;
import java.io.*;

public class FileCreationDemo {
	public static void main(String[] args) {
		try {
			createFileUsingFileOutputStream();
	        createFileUsingFileClass();
		} catch (Exception e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
	
	 public static void createFileUsingFileClass() {
	        try {
	            File file = new File("file_using_file_class.txt");
	            if (file.createNewFile()) {
	                System.out.println("File created using File class.");
	            } else {
	                System.out.println("File already exists.");
	            }
	        } catch (IOException e) {
	            System.out.println("An error occurred while creating the file using File class.");
	            e.printStackTrace();
	        }
	    }
	 
	 public static void createFileUsingFileOutputStream() {
	        try {
	            FileOutputStream fos = new FileOutputStream("file_using_fileoutputstream.txt");
	            fos.close();
	            System.out.println("File created using FileOutputStream.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while creating the file using FileOutputStream.");
	            e.printStackTrace();
	        }
	    }
}
