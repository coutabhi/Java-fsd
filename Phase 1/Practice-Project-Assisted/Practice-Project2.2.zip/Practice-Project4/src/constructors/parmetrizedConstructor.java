package constructors;

class course {
	int courseId;
	String courseName;
	float coursePrice;
	static String classPlatform = "Zoom";
	
	
	// Below is the example of parametrized constructor
	course (int courseId, String courseName, float coursePrice) {
		this.courseId = courseId;
		this.courseName = courseName;
		this.coursePrice = coursePrice;
	}
	
	void courseInfo() {
		System.out.println("The course " + courseName + " having id " + courseId + " and price is Rs. " + coursePrice);
	} 
	
}

public class parmetrizedConstructor {

	public static void main(String[] args) {
		course c1 = new course(195, "Programming in Java", 999);
		// As we know constructor is called during the creation of objects so that we can use parametrized constructor
		// to do some operations before creation of objects
		c1.courseInfo();
		course c2 = new course(185, "Programming in C++", 899);
		c2.courseInfo();
	}
}
