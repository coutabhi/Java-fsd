package constructors;

class student {
	int studentId;
	String studentName;
	String studentStandard;
	
	void studentInfo() {
		System.out.println(studentName + " have id number " + studentId + " studied in " + studentStandard + " class.");
	}
	/*
	 * default constructor is like as below
	 * student() {}
	 * */
}

public class defaultConstructors {

	public static void main(String[] args) {
		student s1 = new student();
		s1.studentId = 101;
		s1.studentName = "Abhishek Yadav";
		s1.studentStandard = "12";
		
		s1.studentInfo(); // When we create object a default constructor is called a constructor
		// is called once in the lifetime of object that is at the time of creation.
	}

}
