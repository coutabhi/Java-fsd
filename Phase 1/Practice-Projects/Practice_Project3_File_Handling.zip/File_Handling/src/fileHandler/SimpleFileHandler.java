
// Source code for the file handling by Abhishek Yadav
package fileHandler;

import java.io.*;
import java.util.Scanner;

public class SimpleFileHandler {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		while (true) {
			System.out.println("Choose an option:");
			System.out.println("1. Create a file");
			System.out.println("2. Read from a file");
			System.out.println("3. Write to a file");
			System.out.println("4. Append to a file");
			System.out.println("5. Exit");

			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				createFile(scanner);
				break;
			case 2:
				readFile(scanner);
				break;
			case 3:
				writeToFile(scanner);
				break;
			case 4:
				appendToFile(scanner);
				break;
			case 5:
				System.out.println("Exiting...");
				scanner.close();
				System.out.println("Exited");
				System.exit(0);
			default:
				System.out.println("Invalid choice. Please try again.");
			}
		}
	}

	// method for creating a file
	private static void createFile(Scanner scanner) {
		scanner.nextLine();
		System.out.println("Enter file name:");
		String fileName = scanner.nextLine();

		try {
			File file = new File(fileName);
			if (file.createNewFile()) {
				System.out.println("File created: " + file.getAbsolutePath());
			} else {
				System.out.println("File already exists.");
			}
		} catch (IOException e) {
			System.err.println("Error creating file: " + e.getMessage());
		}
	}
	
	//method for reading a file
	private static void readFile(Scanner scanner) {
		scanner.nextLine();
		System.out.println("Enter file name to read:");
		String fileName = scanner.nextLine();

		try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
			String line;
			System.out.println("Content read from the file:");
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
		} catch (IOException e) {
			System.err.println("Error reading from the file: " + e.getMessage());
		}
	}

	//method for writing a file
	private static void writeToFile(Scanner scanner) {
		scanner.nextLine();
		System.out.println("Enter file name to write:");
		String fileName = scanner.nextLine();
		System.out.println("Enter content to write:");
		String content = scanner.nextLine();

		try (FileWriter writer = new FileWriter(fileName)) {
			writer.write(content);
			System.out.println("Content successfully written to the file.");
		} catch (IOException e) {
			System.err.println("Error writing to the file: " + e.getMessage());
		}
	}

	// method for appending a file
	private static void appendToFile(Scanner scanner) {
		scanner.nextLine();
		System.out.println("Enter file name to append:");
		String fileName = scanner.nextLine();
		System.out.println("Enter content to append:");
		String content = scanner.nextLine();

		try (FileWriter writer = new FileWriter(fileName, true)) {
			writer.write(content + "\n");
			System.out.println("Content successfully appended to the file.");
		} catch (IOException e) {
			System.err.println("Error appending to the file: " + e.getMessage());
		}
	}
}
