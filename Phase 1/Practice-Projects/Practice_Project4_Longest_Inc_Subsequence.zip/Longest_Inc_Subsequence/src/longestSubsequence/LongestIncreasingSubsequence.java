package longestSubsequence;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LongestIncreasingSubsequence {

	public static List<Integer> longestIncreasingSubsequence(int[] nums) {
		if (nums == null || nums.length == 0) {
			return new ArrayList<>();
		}

		List<Integer> lis = new ArrayList<>();
		lis.add(nums[0]);

		for (int i = 1; i < nums.length; i++) {
			if (nums[i] > lis.get(lis.size() - 1)) {
				lis.add(nums[i]);
			} else {
				int insertionPoint = findInsertionPoint(lis, nums[i]);
				lis.set(insertionPoint, nums[i]);
			}
		}

		return lis;
	}

	private static int findInsertionPoint(List<Integer> lis, int num) {
		int low = 0;
		int high = lis.size() - 1;

		while (low < high) {
			int mid = low + (high - low) / 2;
			if (lis.get(mid) < num) {
				low = mid + 1;
			} else {
				high = mid;
			}
		}

		return low;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int n;
		
		while(true) {
			System.out.print("Enter the number of elements: ");
			n = scanner.nextInt();
			if(n>=100) {
				System.out.println("Please enter value less than 100");
			}
			break;
		}

		
		
		int[] input = new int[n];
		System.out.println("Enter the elements:");
		for (int i = 0; i < n; i++) {
			input[i] = scanner.nextInt();
		}

		List<Integer> longestSubsequence = longestIncreasingSubsequence(input);

		System.out.println("Longest Increasing Subsequence: " + longestSubsequence);

		scanner.close();
	}
}
