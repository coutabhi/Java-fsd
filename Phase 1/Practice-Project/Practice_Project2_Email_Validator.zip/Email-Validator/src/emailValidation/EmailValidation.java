package emailValidation;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidation {

    public static void main(String[] args) {
        String[] employeeEmails = {
            "abhiyadav0905@gmail.com",
            "testing123@gmail.com",
            "testing@outlook.com",
            // Add more email IDs as needed
        };

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an email ID to search: ");
        String userInput = scanner.nextLine();

        boolean isValid = validateEmail(userInput);
        boolean found = false;

        if (isValid) {
            for (String email : employeeEmails) {
                if (userInput.equals(email)) {
                    found = true;
                    break;
                }
            }

            if (found) {
                System.out.println("Email ID found in the list: " + userInput);
            } else {
                System.out.println("Email ID not found in the list.");
            }
        } else {
            System.out.println("Invalid email format. Please enter a valid email ID.");
        }

        scanner.close();
    }

    public static boolean validateEmail(String email) {
        String regex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
}

