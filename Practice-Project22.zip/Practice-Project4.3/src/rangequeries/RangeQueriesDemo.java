package rangequeries;

public class RangeQueriesDemo {
	public static void main(String[] args) {
		int[] arr = { 1, 2, 4, 3, 7, 9 };
		int n = arr.length;

		int lower = 1; 
		int upper = 4;

		if (lower < 0 || upper >= n || lower > upper) {
			System.out.println("Invalid range or array length");
		} else {
			int sum = findRangeSum(arr, lower, upper);
			System.out.println("Sum of elements within the range [" + lower + ", " + upper + "] is: " + sum);
		}
	}

	public static int findRangeSum(int[] arr, int L, int R) {
		int n = arr.length;

		int[] calSum = new int[n];
		calSum[0] = arr[0];

		for (int i = 1; i < n; i++) {
			calSum[i] = calSum[i - 1] + arr[i];
		}

		int rangeSum = calSum[R] - (L > 0 ? calSum[L - 1] : 0);
		return rangeSum;
	}
}
