package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.connections.DBConnection;

/**
 * Servlet implementation class DBOperations
 */
@WebServlet("/DBOperations")
public class DBOperations extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DBOperations() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		try {
			DBConnection dbConnection = new DBConnection();
			Connection conn = dbConnection.getConnection();
			Statement statement = conn.createStatement();

			String action = request.getParameter("action");

			if ("create".equals(action)) {
				// Create the database
				statement.executeUpdate("CREATE DATABASE IF NOT EXISTS abhidatabase");
				out.println("<html><body>");
				out.println("<h1>Database created successfully!</h1>");
				out.println("</body></html>");
			} else if ("use".equals(action)) {
				// Use the database
				statement.executeUpdate("USE abhidatabase");
				out.println("<html><body>");
				out.println("<h1>Using the database!</h1>");
				out.println("</body></html>");
			} else if ("drop".equals(action)) {
				// Drop the database
				statement.executeUpdate("DROP DATABASE IF EXISTS abhidatabase");
				out.println("<html><body>");
				out.println("<h1>Database dropped successfully!</h1>");
				out.println("</body></html>");
			} else {
				out.println("<html><body>");
				out.println("<h1>Invalid action requested!</h1>");
				out.println("</body></html>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			out.println("<html><body>");
			out.println("<h1>Error executing database operations.</h1>");
			out.println("<p>" + e.getMessage() + "</p>");
			out.println("</body></html>");
		} finally {
			out.close();
		}
	}

}
