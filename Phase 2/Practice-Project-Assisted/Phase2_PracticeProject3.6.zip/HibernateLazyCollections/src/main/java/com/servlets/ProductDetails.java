package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ecommerce.EProduct;
import com.ecommerce.HibernateUtil;

/**
 * Servlet implementation class ProductDetails
 */
@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		try {
			SessionFactory factory = HibernateUtil.getSessionFactory();

			Session session = factory.openSession();

			// Begin a transaction
			session.beginTransaction();

			// Fetch data using lazy collections
			List<EProduct> products = session.createQuery("FROM EProduct", EProduct.class).getResultList();

			// Commit the transaction
			session.getTransaction().commit();

			// Close the session
			session.close();

			// Display the data
			out.println("<html><body><h2>Product Details:</h2>");
			for (EProduct product : products) {
				Hibernate.initialize(product.getPrice());
				out.println("<p>ID: " + product.getID() + "<br>");
				out.println("Price: " + product.getPrice() + "<br>");
			}
			out.println("</body></html>");

		} catch (Exception ex) {
			throw ex;
		}

	}

}
