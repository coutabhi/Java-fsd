package com.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.entity.Product;

public class ProductMain {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory sf = cfg.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Product pro = new Product();
		pro.setProduct_id(101);
		pro.setProduct_name("Cotton Shirt");
		pro.setProduct_price(1999);
		
		session.save(pro);
		trans.commit();
		
		session.close();
		sf.close();
		
		System.out.println("New Product added.");
	}

}
