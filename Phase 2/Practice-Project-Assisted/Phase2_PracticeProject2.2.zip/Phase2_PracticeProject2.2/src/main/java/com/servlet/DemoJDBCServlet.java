package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


@WebServlet("/DemoJDBCServlet")
public class DemoJDBCServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<h1>Initializing JDBC Connection</h1>");

		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcdemo", "root",
					"Password@123");
			out.println("<p>JDBC Connection established successfully!</p>");
			out.println("<p>To close the connection click on stop <a href='CloseConnection'>stop connection</a>");
		} catch (ClassNotFoundException | SQLException e) {
			out.println("<p>Error: " + e.getMessage() + "</p>");
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					out.println("<p>Error closing the connection: " + e.getMessage() + "</p>");
				}
			}
		}

		out.println("</body></html>");
		out.close();
	}
}
