package com.servlets;
import com.connections.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DemoJDBC")
public class DemoJDBC extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>JDBC Servlet Demo</h1>");

        DBConnection dbConnection = new DBConnection();
        Connection conn = dbConnection.getConnection();

        if (conn != null) {
            out.println("<p>Connection established successfully!</p>");
            // Perform database operations if needed
        } else {
            out.println("<p>Failed to establish a connection to the database.</p>");
        }

        dbConnection.closeConnection();
        
        out.println("<p>Connection closed successfully!</p>");

        out.println("</body></html>");
        out.close();
    }
}
