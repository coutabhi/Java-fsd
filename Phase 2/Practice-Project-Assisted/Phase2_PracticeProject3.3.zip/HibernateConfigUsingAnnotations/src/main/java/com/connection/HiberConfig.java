package com.connection;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HiberConfig {
	public HiberConfig() {
	   }

	   public static SessionFactory GetConnection() {
	      Configuration configuration = new Configuration();
	      configuration.addAnnotatedClass(com.entity.Product.class);
	      Properties properties = new Properties();
	      properties.put("hibernate.connection.driver_class", "com.mysql.cj.jdbc.Driver");
	      properties.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/ecommerce");
	      properties.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
	      properties.put("hibernate.connection.username", "root");
	      properties.put("hibernate.connection.password", "Password@123");
	      properties.put("hibernate.hbm2ddl.auto", "update");
	      properties.put("hibernate.show_sql", true);
	      configuration.setProperties(properties);
	      
	      SessionFactory sessionFactory = configuration.buildSessionFactory();
	      return sessionFactory;
	   }
}
