package com.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.connection.HiberConfig;
import com.entity.Product;

public class ProductMain {

	public static void main(String[] args) {
		SessionFactory sf = HiberConfig.GetConnection();
		
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Product pro = new Product();
		pro.setProduct_name("red Shirt");
		pro.setProduct_price(1999);
		
		session.save(pro);
		trans.commit();
		
		session.close();
		sf.close();
		
		System.out.println("New Product added.");
	}

}
