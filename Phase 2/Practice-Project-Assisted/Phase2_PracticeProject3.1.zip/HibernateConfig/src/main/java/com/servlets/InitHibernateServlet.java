package com.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.SessionFactory;

import com.connections.HiberConfig;

/**
 * Servlet implementation class InitHibernateServlet
 */
@WebServlet("/InitHibernateServlet")
public class InitHibernateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InitHibernateServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// Initialize Hibernate
			SessionFactory sessionFactory = HiberConfig.GetConnection();

			// You can store the sessionFactory in a servlet context attribute for later use
			getServletContext().setAttribute("sessionFactory", sessionFactory);

			response.getWriter().println("Hibernate has been initialized successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().println("Error initializing Hibernate: " + e.getMessage());
		}
	}

}
