package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.connections.DBConnection;

/**
 * Servlet implementation class ProductDetails
 */
@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			PrintWriter out = response.getWriter();
			out.println("<html><body>");

			DBConnection dbConnection = new DBConnection();
			Connection conn = dbConnection.getConnection();
			String action = request.getParameter("action");
			if ("insert".equals(action)) {
				// Insert product
				String productName = request.getParameter("productName");
				double productPrice = Double.parseDouble(request.getParameter("productPrice"));

				String sql = "INSERT INTO eproduct (name, price, date_added) VALUES (?, ?, now())";

				PreparedStatement statement = conn.prepareStatement(sql);
				statement.setString(1, productName);
				statement.setDouble(2, productPrice);
				statement.executeUpdate();

				out.println("<html><body>");
				out.println("<h1>Product inserted successfully!</h1>");
				out.println("</body></html>");
			} else if ("update".equals(action)) {
				// Update product

				String productName = request.getParameter("productName");
				double productPrice = Double.parseDouble(request.getParameter("productPrice"));
				
				String deleteSql = "UPDATE eproduct SET name = ?, price = ?  WHERE name = ?";
				PreparedStatement updateStatement  = conn.prepareStatement(deleteSql);
				updateStatement .setString(1, productName);
				updateStatement .setDouble(2, productPrice);
				updateStatement .setString(3, productName);
				int rowsAffected = updateStatement .executeUpdate();

				if (rowsAffected > 0) {
					out.println("<h1>Price updated successfully!</h1>");
				} else {
					out.println("<h1>No product found with the given name</h1>");
				}
			} else if ("delete".equals(action)) {
				// Delete product

				String productName = request.getParameter("productName");
				String deleteSql = "DELETE FROM eproduct WHERE name = ?";
				PreparedStatement deleteStatement = conn.prepareStatement(deleteSql);

				deleteStatement.setString(1, productName);
				int rowsAffected = deleteStatement.executeUpdate();

				if (rowsAffected > 0) {
					out.println("<h1>Product deleted successfully!</h1>");
				} else {
					out.println("<h1>No product found with the given name</h1>");
				}
			} else {
				out.println("<html><body>");
				out.println("<h1>Invalid action requested!</h1>");
				out.println("</body></html>");
			}

			out.println("</body></html>");
			dbConnection.closeConnection();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}

}
