package exponentialsearch;

public class ExponentialSearchExample {

	public static boolean exponentialSearch(int[] arr, int target) {
		int n = arr.length;
		
		if (arr[0] == target) {
			return true;
		}

		int i = 1;
		while (i < n && arr[i] <= target) {
			i *= 2;
		}

		return binarySearch(arr, target, i / 2, Math.min(i, n - 1));
	}

	public static boolean binarySearch(int[] arr, int target, int left, int right) {
		while (left <= right) {
			int mid = left + (right - left) / 2;

			if (arr[mid] == target) {
				return true;
			}

			if (arr[mid] < target) {
				left = mid + 1;
			} else {
				right = mid - 1;
			}
		}

		return false;
	}

	public static void main(String[] args) {
		int[] sortedArray = { 23, 48, 56, 61, 70, 74, 89 };

		int elementToFind = 56;

		boolean isElementFound = exponentialSearch(sortedArray, elementToFind);

		if (isElementFound) {
			System.out.println("Element " + elementToFind + " found in the array.");
		} else {
			System.out.println("Element " + elementToFind + " not found in the array.");
		}
	}
}
