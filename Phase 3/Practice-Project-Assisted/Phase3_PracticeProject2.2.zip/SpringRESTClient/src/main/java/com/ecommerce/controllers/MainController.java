package com.ecommerce.controllers;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import com.ecommerce.beans.Quote;

import java.util.List;

@Controller
public class MainController {

    @GetMapping("/")
    @ResponseBody
    public String index() {

        RestTemplate restTemplate = new RestTemplate();

        // Use ParameterizedTypeReference to handle generic type List<Quote>
        ResponseEntity<List<Quote>> responseEntity = restTemplate.exchange(
                "https://type.fit/api/quotes",
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<Quote>>() {}
        );

        List<Quote> quotes = responseEntity.getBody();

        // Handle the list of quotes as needed
        StringBuilder response = new StringBuilder();
        for (Quote quote : quotes) {
            response.append("Text: ").append(quote.getValue()).append(", Author: ").append(quote.toString()).append("\n");
        }

        return response.toString();
    }
}
